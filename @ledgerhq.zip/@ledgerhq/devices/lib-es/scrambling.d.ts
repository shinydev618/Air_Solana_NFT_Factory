/// <reference types="node" />
export declare function wrapApdu(apdu: Buffer, key: Buffer): Buffer;
//# sourceMappingURL=scrambling.d.ts.map