/// <reference types="node" />
import { Observable } from "rxjs";
export declare const receiveAPDU: (rawStream: Observable<Buffer>) => Observable<Buffer>;
//# sourceMappingURL=receiveAPDU.d.ts.map