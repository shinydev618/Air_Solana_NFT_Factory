/// <reference types="node" />
import { Observable } from "rxjs";
export declare const sendAPDU: (write: (arg0: Buffer) => Promise<void>, apdu: Buffer, mtuSize: number) => Observable<Buffer>;
//# sourceMappingURL=sendAPDU.d.ts.map