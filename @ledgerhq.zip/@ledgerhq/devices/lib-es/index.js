var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a;
import semver from "semver";
/**
 * The USB product IDs will be defined as MMII, encoding a model (MM) and an interface bitfield (II)
 *
 ** Model
 * Ledger Nano S : 0x10
 * Ledger Blue : 0x00
 * Ledger Nano X : 0x40
 *
 ** Interface support bitfield
 * Generic HID : 0x01
 * Keyboard HID : 0x02
 * U2F : 0x04
 * CCID : 0x08
 * WebUSB : 0x10
 */
export var IIGenericHID = 0x01;
export var IIKeyboardHID = 0x02;
export var IIU2F = 0x04;
export var IICCID = 0x08;
export var IIWebUSB = 0x10;
export var DeviceModelId;
(function (DeviceModelId) {
    DeviceModelId["blue"] = "blue";
    DeviceModelId["nanoS"] = "nanoS";
    DeviceModelId["nanoSP"] = "nanoSP";
    DeviceModelId["nanoX"] = "nanoX";
    DeviceModelId["nanoFTS"] = "nanoFTS";
})(DeviceModelId || (DeviceModelId = {}));
var devices = (_a = {},
    _a[DeviceModelId.blue] = {
        id: DeviceModelId.blue,
        productName: "Ledger Blue",
        productIdMM: 0x00,
        legacyUsbProductId: 0x0000,
        usbOnly: true,
        memorySize: 480 * 1024,
        masks: [0x31000000, 0x31010000],
        getBlockSize: function (_firwareVersion) { return 4 * 1024; }
    },
    _a[DeviceModelId.nanoS] = {
        id: DeviceModelId.nanoS,
        productName: "Ledger Nano S",
        productIdMM: 0x10,
        legacyUsbProductId: 0x0001,
        usbOnly: true,
        memorySize: 320 * 1024,
        masks: [0x31100000],
        getBlockSize: function (firmwareVersion) {
            var _a;
            return semver.lt((_a = semver.coerce(firmwareVersion)) !== null && _a !== void 0 ? _a : "", "2.0.0")
                ? 4 * 1024
                : 2 * 1024;
        }
    },
    _a[DeviceModelId.nanoSP] = {
        id: DeviceModelId.nanoSP,
        productName: "Ledger Nano S Plus",
        productIdMM: 0x50,
        legacyUsbProductId: 0x0005,
        usbOnly: true,
        memorySize: 1536 * 1024,
        masks: [0x33100000],
        getBlockSize: function (_firmwareVersion) { return 32; }
    },
    _a[DeviceModelId.nanoX] = {
        id: DeviceModelId.nanoX,
        productName: "Ledger Nano X",
        productIdMM: 0x40,
        legacyUsbProductId: 0x0004,
        usbOnly: false,
        memorySize: 2 * 1024 * 1024,
        masks: [0x33000000],
        getBlockSize: function (_firwareVersion) { return 4 * 1024; },
        bluetoothSpec: [
            {
                serviceUuid: "13d63400-2c97-0004-0000-4c6564676572",
                notifyUuid: "13d63400-2c97-0004-0001-4c6564676572",
                writeUuid: "13d63400-2c97-0004-0002-4c6564676572",
                writeCmdUuid: "13d63400-2c97-0004-0003-4c6564676572"
            },
        ]
    },
    _a[DeviceModelId.nanoFTS] = {
        id: DeviceModelId.nanoFTS,
        productName: "Ledger Nano FTS",
        productIdMM: 0x60,
        legacyUsbProductId: 0x0006,
        usbOnly: false,
        memorySize: 2 * 1024 * 1024,
        masks: [0x33200000],
        getBlockSize: function (_firwareVersion) { return 4 * 1024; },
        bluetoothSpec: [
            {
                serviceUuid: "13d63400-2c97-6004-0000-4c6564676572",
                notifyUuid: "13d63400-2c97-6004-0001-4c6564676572",
                writeUuid: "13d63400-2c97-6004-0002-4c6564676572",
                writeCmdUuid: "13d63400-2c97-6004-0003-4c6564676572"
            },
        ]
    },
    _a);
var productMap = {
    Blue: DeviceModelId.blue,
    "Nano S": DeviceModelId.nanoS,
    "Nano S Plus": DeviceModelId.nanoSP,
    "Nano X": DeviceModelId.nanoX,
    "Nano FTS": DeviceModelId.nanoFTS
};
var devicesList = Object.values(devices);
/**
 *
 */
export var ledgerUSBVendorId = 0x2c97;
/**
 *
 */
export var getDeviceModel = function (id) {
    var info = devices[id];
    if (!info)
        throw new Error("device '" + id + "' does not exist");
    return info;
};
/**
 * Given a `targetId`, return the deviceModel associated to it,
 * based on the first two bytes.
 */
export var identifyTargetId = function (targetId) {
    var deviceModel = devicesList.find(function (_a) {
        var masks = _a.masks;
        return masks.find(function (mask) { return (targetId & 0xffff0000) === mask; });
    });
    return deviceModel;
};
/**
 *
 */
export var identifyUSBProductId = function (usbProductId) {
    var legacy = devicesList.find(function (d) { return d.legacyUsbProductId === usbProductId; });
    if (legacy)
        return legacy;
    var mm = usbProductId >> 8;
    var deviceModel = devicesList.find(function (d) { return d.productIdMM === mm; });
    return deviceModel;
};
export var identifyProductName = function (productName) {
    var deviceModel = devicesList.find(function (d) { return d.id === productMap[productName]; });
    return deviceModel;
};
var bluetoothServices = [];
var serviceUuidToInfos = {};
for (var id in devices) {
    var deviceModel = devices[id];
    var bluetoothSpec = deviceModel.bluetoothSpec;
    if (bluetoothSpec) {
        for (var i = 0; i < bluetoothSpec.length; i++) {
            var spec = bluetoothSpec[i];
            bluetoothServices.push(spec.serviceUuid);
            serviceUuidToInfos[spec.serviceUuid] = serviceUuidToInfos[spec.serviceUuid.replace(/-/g, "")] = __assign({ deviceModel: deviceModel }, spec);
        }
    }
}
/**
 *
 */
export var getBluetoothServiceUuids = function () { return bluetoothServices; };
/**
 *
 */
export var getInfosForServiceUuid = function (uuid) { return serviceUuidToInfos[uuid.toLowerCase()]; };
//# sourceMappingURL=index.js.map