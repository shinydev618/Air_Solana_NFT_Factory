/**
 * A Log object
 */
export interface Log {
    type: string;
    message?: string;
    data?: any;
    id: string;
    date: Date;
}
export declare type Unsubscribe = () => void;
export declare type Subscriber = (arg0: Log) => void;
/**
 * log something
 * @param type a namespaced identifier of the log (it is not a level like "debug", "error" but more like "apdu-in", "apdu-out", etc...)
 * @param message a clear message of the log associated to the type
 */
export declare const log: (type: string, message?: string | undefined, data?: any) => void;
/**
 * listen to logs.
 * @param cb that is called for each future log() with the Log object
 * @return a function that can be called to unsubscribe the listener
 */
export declare const listen: (cb: Subscriber) => Unsubscribe;
declare global {
    interface Window {
        __ledgerLogsListen: any;
    }
}
//# sourceMappingURL=index.d.ts.map